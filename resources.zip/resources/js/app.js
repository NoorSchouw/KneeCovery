/**
 * jQuery + helpers
 */
import $ from 'jquery';
window.$ = window.jQuery = $;

import moment from 'moment';
window.moment = moment;

/**
 * Bootstrap / Core UI
 */
import 'bootstrap';
import 'overlayscrollbars';
import 'daterangepicker';

/**
 * ApexCharts
 */
import ApexCharts from 'apexcharts';
window.ApexCharts = ApexCharts;

/**
 * Dropzone
 */
import Dropzone from 'dropzone';
window.Dropzone = Dropzone;

/**
 * Quill editor
 */
import Quill from 'quill';
window.Quill = Quill;

/**
 * DataTables (de NPM ES6 module manier)
 */
import DataTable from "datatables.net-bs5";
import "datatables.net-buttons-bs5";
import "datatables.net-responsive-bs5";

// make it globally available
window.DataTable = DataTable;

/**
 * Styles for plugins via NPM
 */
import 'overlayscrollbars/css/OverlayScrollbars.css';
import 'daterangepicker/daterangepicker.css';
import 'dropzone/dist/dropzone.css';
import 'quill/dist/quill.snow.css';
import 'datatables.net-bs5/css/dataTables.bootstrap5.css';
import 'datatables.net-buttons-bs5/css/buttons.bootstrap5.css';

/**
 * Custom scripts
 */
import './custom-scrollbar';
import './custom-daterange';
import './custom';
import './validations';
import './authentification';
