<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KneeCovery - Forgot Password</title>

    <!-- Meta -->
    <meta name="description" content="Marketplace for Bootstrap Admin Dashboards">
    <meta property="og:title" content="Admin Templates - Dashboard Templates">
    <meta property="og:description" content="Marketplace for Bootstrap Admin Dashboards">
    <meta property="og:type" content="Website">
    <link rel="shortcut icon" href="{{ asset ('assets/images/favicon.svg') }}">

    <!-- *************
			************ CSS Files *************
		************* -->
    <link rel="stylesheet" href="{{ asset ('assets/fonts/remix/remixicon.css') }}">
    <link rel="stylesheet" href="{{ asset ('assets/css/main.css') }}">

</head>

<body class="login-bg">

<!-- Container starts -->
<div class="container">

    <!-- Auth wrapper starts -->
    <div class="auth-wrapper">

        <!-- Form starts -->
        <form action="index.html">

            <div class="auth-box">
                <a href="index.html" class="auth-logo mb-4">
                    <img src="assets/images/logo.svg" alt="Bootstrap Gallery">
                </a>

                <h6 class="fw-light mb-4">In order to access your dashboard, please enter the email ID you provided during
                    the
                    registration process.</h6>

                <div class="mb-3">
                    <label class="form-label" for="email">Your email <span class="text-danger">*</span></label>
                    <input type="text" id="email" class="form-control" placeholder="Enter your email">
                </div>

                <div class="mb-3 d-grid">
                    <button type="submit" class="btn btn-primary">
                        Submit
                    </button>
                </div>
            </div>

        </form>
        <!-- Form ends -->

    </div>
    <!-- Auth wrapper ends -->

</div>
<!-- Container ends -->

</body>

</html>
